# Electron

[The new demo](https://docs.sheetjs.com/docs/demos/desktop#electron)
includes an improved example and detailed explanations.

[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/js-xlsx?pixel)](https://github.com/SheetJS/js-xlsx)
