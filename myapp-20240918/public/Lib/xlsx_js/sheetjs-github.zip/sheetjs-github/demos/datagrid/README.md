# canvas-datagrid

[The new demo](https://docs.sheetjs.com/docs/demos/grid#canvas-datagrid)
includes a live example and improved explanations.


[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/js-xlsx?pixel)](https://github.com/SheetJS/js-xlsx)
