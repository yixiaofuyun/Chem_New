# Typed Arrays and Math

[The new demo](https://docs.sheetjs.com/docs/demos/ml) includes 
interactive examples as well as strategies for CSV and JS Array interchange.

[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/js-xlsx?pixel)](https://github.com/SheetJS/js-xlsx)
