/*# vim: set ts=2: */
/*::

declare module './' { declare module.exports:SSFModule; };
declare module '../' { declare module.exports:SSFModule; };
declare module 'ssf' { declare module.exports:SSFModule; };
*/
