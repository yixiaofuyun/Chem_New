![logo](./img/opencv-logo-small.png)

# OpenCV.js <small>v3.x</small>

> 一个前端OpenCV库

<!-- - 简单、轻便 (压缩后 ~21kB)
- 无需生成 html 文件
- 众多主题 -->

[GitHub](https://github.com/moqi-y/openCV.js-doc-zh)
[快速上手](#opencvjs简介)